#! /bin/bash
echo -e "\e[1;34m" > /dev/tty0
echo "========================> Hello guys,Welcome to Recovery! <========================" > /dev/tty0
sleep 3
echo -e "\n----->Start updater <-----\n"
updater -d -f &
